import "../styles/base.css";
import "../styles/Footer.css";

const Footer = () => {
  return (
    <div className="border">
      <footer>
        <p>&copy; 2025 moo.v</p>
      </footer>
    </div>
  );
};

export default Footer;
