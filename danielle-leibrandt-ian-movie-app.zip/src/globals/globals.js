export const APP_TITLE          = "moo.v";
export const REGION             = "region=CA|US";
export const URL_IMAGE          = "https://www.themoviedb.org/t/p/";
export const endPointSearch     = "https://api.themoviedb.org/3/search/movie";
export const endPointPopular    = "https://api.themoviedb.org/3/movie/popular";
export const endPointTopRated   = "https://api.themoviedb.org/3/movie/top_rated";
export const endPointUpcoming   = "https://api.themoviedb.org/3/movie/upcoming";
export const endPointNowPlaying = "https://api.themoviedb.org/3/movie/now_playing";
